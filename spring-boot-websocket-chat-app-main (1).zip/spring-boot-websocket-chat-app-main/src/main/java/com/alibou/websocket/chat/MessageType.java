package com.alibou.websocket.chat;

public enum MessageType {

    CHAT,
    JOIN,
    LEAVE
}
